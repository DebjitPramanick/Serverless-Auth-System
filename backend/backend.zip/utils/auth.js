const jwt = require('jsonwebtoken')

export function generateToken(user){
    if(!user) return null;

    return jwt.sign(user, 'mysecret',{
        expiresIn: '1h'
    })
}

export function verifyToken(username, token){
    if(!user) return null;

    return jwt.verify(token, 'mysecret',(err, res) => {
        if(err){
            return {
                verified: false,
                message: 'Invalid token.'
            }
        }
        if(res.username !== username){
            return {
                verified: false,
                message: 'Invalid user.'
            }
        }
        return {
            verified: true,
            message: 'Verified.'
        }
    })
}