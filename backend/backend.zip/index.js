const registerService = require('./services/register.js')
const loginService = require('./services/login.js')
const verifyService = require('./services/verify.js')
const utils = require('./utils/utils.js')

const HEALTH_PATH = '/health';
const REGISTER_PATH = '/register';
const LOGIN_PATH = '/login';
const VERIFY_PATH = '/verify';

exports.handler = async (event) => {
    let res;
    
    switch(true){
        case event.httpMethod === 'GET' && event.path === HEALTH_PATH:
            res = utils.buildResponse(200);
            break;
        case event.httpMethod === 'POST' && event.path === REGISTER_PATH:
            const requestBody = JSON.stringify(event.body)
            res = registerService.register(requestBody)
            break;
        case event.httpMethod === 'POST' && event.path === LOGIN_PATH:
            const requestBody = JSON.stringify(event.body)
            res = loginService.login(requestBody)
            break;
        case event.httpMethod === 'POST' && event.path === VERIFY_PATH:
            const requestBody = JSON.stringify(event.body)
            res = verifyService.verify(requestBody)
            break;
        default:
            res = utils.buildResponse(404, '404 Not Found.');
            break;
    }
    return res;
};

